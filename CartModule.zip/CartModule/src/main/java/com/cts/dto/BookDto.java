package com.cts.dto;

import lombok.Data;

@Data
public class BookDto {
	private Long bookId;
	private String title;
	private Double price;

}
